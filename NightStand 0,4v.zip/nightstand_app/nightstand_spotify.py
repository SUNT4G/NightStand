"""Nightstand — temporizador fullscreen con checklist diaria y controles Spotify.

Requisitos: Python 3.10+, Tkinter, spotipy, Pillow y keyring.
Las credenciales y el token OAuth se guardan mediante keyring cuando hay un
backend de almacenamiento seguro disponible (Administrador de credenciales en
Windows). Si no lo hay, la aplicación mantiene esos datos únicamente en memoria.

Spotify controla la reproducción en un dispositivo Spotify Connect existente;
esta aplicación no transmite ni decodifica audio por sí misma.
"""
from __future__ import annotations

import io
import json
import math
import os
from datetime import date
from pathlib import Path
import secrets
import threading
import time
import tkinter as tk
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, HTTPServer
from tkinter import messagebox, ttk
from urllib.error import URLError
from urllib.parse import parse_qs, urlparse
from urllib.request import urlopen

try:
    import spotipy
    from spotipy.cache_handler import CacheHandler
    from spotipy.oauth2 import SpotifyOAuth
    SPOTIPY_AVAILABLE = True
except ImportError:
    spotipy = None  # type: ignore[assignment]
    SpotifyOAuth = None  # type: ignore[assignment,misc]

    class CacheHandler:  # type: ignore[no-redef]
        """Stub para permitir usar el temporizador si falta Spotipy."""
        pass

    SPOTIPY_AVAILABLE = False

try:
    import keyring
except ImportError:
    keyring = None

try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    Image = ImageTk = None  # type: ignore[assignment]
    PIL_AVAILABLE = False

APP_TITLE = "NIGHTSTAND"
BG = "#08090B"
PANEL = "#121419"
PANEL_2 = "#1B1E25"
TEXT = "#F1EDE6"
MUTED = "#969CA8"
MINT = "#BDF7D5"
MINT_DARK = "#244C3C"
PINK = "#F4B7C7"
SKY = "#A9DDF2"
CREAM = "#F3E1C9"
LAVENDER = "#C8B9ED"
SPOTIFY_GREEN = "#1ED760"
RED = "#E8A2A2"
REDIRECT_URI = "http://127.0.0.1:8888/callback"
SPOTIFY_SCOPES = "user-read-playback-state user-modify-playback-state user-read-currently-playing"
KEYRING_SERVICE = "NightstandSpotifyTimer"
_TOKEN_MEMORY_CACHE: dict[str, dict] = {}


def _keyring_usable() -> bool:
    """Avoid known plaintext/fail keyring backends; never write secrets to a file."""
    if keyring is None:
        return False
    try:
        backend = keyring.get_keyring()
        name = type(backend).__name__.lower()
        module = type(backend).__module__.lower()
        combined = f"{name} {module}"
        if any(term in combined for term in ("plaintext", "null", "fail")):
            return False
        return True
    except Exception:
        return False


class SecureTokenCache(CacheHandler):
    """Spotipy token cache backed by keyring, with process-memory fallback only."""

    def __init__(self, client_id: str):
        self.username = f"oauth_token::{client_id}"
        self._keyring_enabled = _keyring_usable()

    def get_cached_token(self):
        if self._keyring_enabled and keyring is not None:
            try:
                raw = keyring.get_password(KEYRING_SERVICE, self.username)
                if raw:
                    value = json.loads(raw)
                    if isinstance(value, dict):
                        _TOKEN_MEMORY_CACHE[self.username] = value
                        return value
            except Exception:
                # A locked or unavailable credential vault must not crash the timer.
                self._keyring_enabled = False
        return _TOKEN_MEMORY_CACHE.get(self.username)

    def save_token_to_cache(self, token_info):
        _TOKEN_MEMORY_CACHE[self.username] = token_info
        if self._keyring_enabled and keyring is not None:
            try:
                keyring.set_password(KEYRING_SERVICE, self.username, json.dumps(token_info))
            except Exception:
                self._keyring_enabled = False


def _receive_oauth_code(redirect_uri: str, expected_state: str, auth_url: str,
                        timeout: int = 180,
                        cancel_event: threading.Event | None = None) -> str:
    """Wait for Spotify's redirect on loopback; never prints or logs the code."""
    parsed_redirect = urlparse(redirect_uri)
    if parsed_redirect.scheme != "http" or parsed_redirect.hostname != "127.0.0.1" or not parsed_redirect.port:
        raise ValueError("El URI debe usar http://127.0.0.1:PUERTO/ruta para el inicio de sesión local.")
    target_path = parsed_redirect.path or "/"
    shared: dict[str, str | None] = {"code": None, "state": None, "error": None}

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802 - required by BaseHTTPRequestHandler
            request = urlparse(self.path)
            query = parse_qs(request.query)
            if request.path != target_path:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"Callback path not found.")
                return
            shared["code"] = query.get("code", [None])[0]
            shared["state"] = query.get("state", [None])[0]
            shared["error"] = query.get("error", [None])[0]
            page = (
                "<!doctype html><html><head><meta charset='utf-8'><title>Nightstand</title></head>"
                "<body style='background:#08090b;color:#f1ede6;font-family:Segoe UI,Arial;padding:3em'>"
                "<h2>Spotify conectado / respuesta recibida</h2>"
                "<p>Puedes cerrar esta pestaña y volver a Nightstand.</p></body></html>"
            ).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(page)))
            self.end_headers()
            self.wfile.write(page)

        def log_message(self, _format, *_args):
            return  # Do not log callback URLs or authorization codes.

    # Bind the callback socket before opening the browser, avoiding a fast-login race.
    server = HTTPServer(("127.0.0.1", parsed_redirect.port), CallbackHandler)
    server.timeout = 1
    deadline = time.monotonic() + timeout
    try:
        webbrowser.open(auth_url, new=1, autoraise=True)
        while (shared["code"] is None and shared["error"] is None
               and time.monotonic() < deadline
               and not (cancel_event and cancel_event.is_set())):
            server.handle_request()
    finally:
        server.server_close()

    if cancel_event and cancel_event.is_set():
        raise RuntimeError("Autorización de Spotify cancelada al cerrar la aplicación.")
    if time.monotonic() >= deadline and shared["code"] is None and shared["error"] is None:
        raise TimeoutError("No se recibió la autorización de Spotify en 3 minutos.")
    if shared["error"]:
        raise RuntimeError(f"Spotify rechazó la autorización: {shared['error']}")
    if not secrets.compare_digest(str(shared["state"] or ""), expected_state):
        raise RuntimeError("La comprobación de seguridad OAuth (state) no coincide.")
    code = shared["code"]
    if not code:
        raise RuntimeError("Spotify no devolvió un código de autorización.")
    return code


class NightstandApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title(APP_TITLE)
        root.configure(bg=BG)
        root.minsize(900, 600)
        try:
            root.attributes("-fullscreen", True)
        except tk.TclError:
            root.state("zoomed")

        self.is_fullscreen = True
        self.closing = False
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="spotify-worker")
        self.cancel_event = threading.Event()
        self.spotify_pending = False
        self.sp_client = None
        self.spotify_client_id = ""
        self.spotify_client_secret = ""
        self.redirect_uri = REDIRECT_URI
        self.spotify_poll_job = None
        self.track_progress_job = None
        self.album_photo = None
        self.sidebar_visible = True
        self._last_art_url = None
        # Playback progress is interpolated locally every second between API syncs.
        self._current_track_id = None
        self._playback_progress_ms = 0
        self._playback_duration_ms = 0
        self._playback_is_playing = False
        self._playback_sync_monotonic = time.monotonic()
        self._volume_after_release = False
        self.tasks_file = self._tasks_storage_path()
        self.task_date = date.today().isoformat()
        self.daily_tasks = self._load_daily_tasks(self.task_date)
        self._daily_task_job = None

        self.timer_state = "idle"  # idle / running / paused / finished
        self.remaining_seconds = 25 * 60
        self.deadline = None
        self._timer_job = None

        self._configure_ttk()
        self._build_layout()
        self._load_saved_credentials()
        self._sync_time_fields()
        self._draw_timer()
        self.root.bind("<Escape>", self._escape_action)
        self.root.bind("<F11>", self.toggle_fullscreen)
        self.root.protocol("WM_DELETE_WINDOW", self.close_app)
        self._tick_timer()
        self._schedule_spotify_poll()
        self._schedule_track_progress_tick()
        self._schedule_task_day_check()

    def _configure_ttk(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Night.TScale", background=PANEL, troughcolor=PANEL_2,
                        sliderthickness=16, borderwidth=0)
        style.configure("Spotify.Horizontal.TProgressbar", troughcolor="#29302B",
                        background=SPOTIFY_GREEN, bordercolor="#111512",
                        lightcolor=SPOTIFY_GREEN, darkcolor=SPOTIFY_GREEN,
                        thickness=4)

    def _build_layout(self):
        self.body = tk.Frame(self.root, bg=BG)
        self.body.pack(fill="both", expand=True)
        self.body.grid_rowconfigure(0, weight=1)
        self.body.grid_columnconfigure(1, weight=1)

        self.sidebar = tk.Frame(self.body, bg=PANEL, width=350, padx=22, pady=20,
                                highlightthickness=1, highlightbackground="#242832")
        self.sidebar.grid(row=0, column=0, sticky="nsw")
        self.sidebar.grid_propagate(False)
        self._build_sidebar()

        self.workspace = tk.Frame(self.body, bg=BG, padx=34, pady=24)
        self.workspace.grid(row=0, column=1, sticky="nsew")
        self.workspace.grid_rowconfigure(1, weight=1)
        self.workspace.grid_columnconfigure(0, weight=1)
        self._build_workspace()

    def _build_sidebar(self):
        header = tk.Frame(self.sidebar, bg=PANEL)
        header.pack(fill="x", pady=(0, 10))
        tk.Label(header, text="NIGHTSTAND", bg=PANEL, fg=TEXT,
                 font=("Segoe UI", 15, "bold")).pack(anchor="w")
        tk.Label(header, text="DAILY FOCUS  /  YOUR PLAN", bg=PANEL, fg=MUTED,
                 font=("Consolas", 9)).pack(anchor="w", pady=(3, 0))

        # Pin the Spotify-style mini player to the bottom of the left sidebar.
        # The daily checklist remains above it and can grow independently.
        self._build_music_bar()
        tk.Frame(self.sidebar, height=1, bg="#30343D").pack(
            side="bottom", fill="x", pady=(0, 12))
        self._build_tasks_panel()

    def _build_music_bar(self):
        """Compact Spotify-inspired player that stays in the sidebar corner."""
        card = tk.Frame(self.sidebar, bg="#111512", padx=11, pady=10,
                        highlightthickness=1, highlightbackground="#29352D")
        card.pack(side="bottom", fill="x", pady=(8, 2))
        self.music_card = card

        heading = tk.Frame(card, bg="#111512")
        heading.pack(fill="x", pady=(0, 9))
        tk.Label(heading, text="●", bg="#111512", fg=SPOTIFY_GREEN,
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 5))
        tk.Label(heading, text="SPOTIFY PLAYER", bg="#111512", fg=TEXT,
                 font=("Consolas", 9, "bold")).pack(side="left")
        settings_button = tk.Button(
            heading, text="AJUSTES", command=self.open_spotify_settings,
            bg="#202722", fg="#CDD5CE", activebackground="#303A32",
            activeforeground=TEXT, relief="flat", bd=0, highlightthickness=0,
            padx=8, pady=3, font=("Segoe UI", 8, "bold"), cursor="hand2")
        settings_button.pack(side="right")

        track_row = tk.Frame(card, bg="#111512")
        track_row.pack(fill="x")
        self.album_art_frame = tk.Frame(track_row, bg="#25352A", width=58, height=58)
        self.album_art_frame.pack_propagate(False)
        self.album_art_frame.pack(side="left", anchor="n", padx=(0, 10))
        self.art_placeholder = tk.Label(
            self.album_art_frame, text="♫", bg="#25352A", fg=SPOTIFY_GREEN,
            font=("Segoe UI Symbol", 16, "bold"), relief="flat", bd=0,
            highlightthickness=0)
        self.art_placeholder.pack(fill="both", expand=True)
        self.track_info = tk.Frame(track_row, bg="#111512")
        self.track_info.pack(side="left", fill="x", expand=True)
        self.track_title = tk.Label(
            self.track_info, text="Sin conexión", bg="#111512", fg=TEXT,
            font=("Segoe UI", 10, "bold"), justify="left", wraplength=180,
            anchor="w")
        self.track_title.pack(fill="x", anchor="w")
        self.track_artist = tk.Label(
            self.track_info, text="Conecta tu cuenta de Spotify", bg="#111512",
            fg="#AAB4AB", font=("Segoe UI", 9), justify="left",
            wraplength=180, anchor="w")
        self.track_artist.pack(fill="x", anchor="w", pady=(3, 0))
        self.track_album = tk.Label(
            self.track_info, text="", bg="#111512", fg="#747F76",
            font=("Segoe UI", 8), justify="left", wraplength=180, anchor="w")
        self.track_album.pack(fill="x", anchor="w", pady=(2, 0))

        progress_row = tk.Frame(card, bg="#111512")
        progress_row.pack(fill="x", pady=(10, 2))
        self.track_elapsed = tk.Label(progress_row, text="0:00", bg="#111512",
                                      fg="#8B968D", font=("Consolas", 7))
        self.track_elapsed.pack(side="left")
        self.track_duration = tk.Label(progress_row, text="0:00", bg="#111512",
                                       fg="#8B968D", font=("Consolas", 7))
        self.track_duration.pack(side="right")
        self.track_progress = ttk.Progressbar(
            card, style="Spotify.Horizontal.TProgressbar", orient="horizontal",
            mode="determinate", maximum=100, value=0)
        self.track_progress.pack(fill="x", pady=(0, 6))

        transport = tk.Frame(card, bg="#111512")
        transport.pack(fill="x", pady=(0, 5))
        transport.grid_columnconfigure(0, weight=1)
        transport.grid_columnconfigure(1, weight=1)
        transport.grid_columnconfigure(2, weight=1)
        self.previous_button = tk.Button(
            transport, text="|◀", command=self.spotify_previous,
            bg="#111512", fg="#C6D0C7", activebackground="#29302B",
            activeforeground=TEXT, relief="flat", bd=0, highlightthickness=0,
            padx=9, pady=4, font=("Segoe UI Symbol", 12, "bold"), cursor="hand2")
        self.previous_button.grid(row=0, column=0)
        self.play_toggle_button = tk.Button(
            transport, text="▶", command=self.spotify_play,
            bg=SPOTIFY_GREEN, fg="#071109", activebackground="#48E47C",
            activeforeground="#071109", relief="flat", bd=0, highlightthickness=0,
            padx=13, pady=5, font=("Segoe UI Symbol", 11, "bold"), cursor="hand2")
        self.play_toggle_button.grid(row=0, column=1, padx=8)
        self.next_button = tk.Button(
            transport, text="▶|", command=self.spotify_next,
            bg="#111512", fg="#C6D0C7", activebackground="#29302B",
            activeforeground=TEXT, relief="flat", bd=0, highlightthickness=0,
            padx=9, pady=4, font=("Segoe UI Symbol", 12, "bold"), cursor="hand2")
        self.next_button.grid(row=0, column=2)

        volume_row = tk.Frame(card, bg="#111512")
        volume_row.pack(fill="x", pady=(2, 0))
        tk.Label(volume_row, text="VOL", bg="#111512", fg="#8B968D",
                 font=("Consolas", 8, "bold")).pack(side="left", padx=(0, 7))
        self.volume_value = tk.Label(volume_row, text="—%", bg="#111512", fg="#B7C6BA",
                                     font=("Consolas", 8))
        self.volume_value.pack(side="right", padx=(7, 0))
        self.volume_scale = tk.Scale(
            volume_row, from_=0, to=100, orient="horizontal", bg="#111512",
            fg=TEXT, troughcolor="#303A32", activebackground=SPOTIFY_GREEN,
            highlightthickness=0, bd=0, showvalue=False, resolution=1,
            command=self._volume_preview, length=160, sliderlength=13,
            cursor="hand2")
        self.volume_scale.set(40)
        self.volume_scale.pack(side="left", fill="x", expand=True)
        self.volume_scale.bind("<ButtonRelease-1>", self._apply_volume)
        self.volume_scale.bind("<Return>", self._apply_volume)

        self.spotify_status = tk.Label(
            card, text="Spotify desconectado · pulsa AJUSTES para conectar",
            bg="#111512", fg="#8B968D", font=("Segoe UI", 8),
            justify="left", wraplength=275, anchor="w")
        self.spotify_status.pack(fill="x", pady=(8, 0))

    def _build_tasks_panel(self):
        """Build a compact, scrollable checklist for the current local day."""
        self.tasks_panel = tk.Frame(self.sidebar, bg=PANEL)
        # Occupy all vertical space left between the header and the pinned music bar.
        self.tasks_panel.pack(fill="both", expand=True, pady=(4, 12))

        title_row = tk.Frame(self.tasks_panel, bg=PANEL)
        title_row.pack(fill="x", pady=(0, 8))
        tk.Label(title_row, text="LISTA DE HOY", bg=PANEL, fg=CREAM,
                 font=("Consolas", 10, "bold")).pack(side="left")
        self.task_date_label = tk.Label(title_row, text=self._format_task_date(),
                                        bg=PANEL, fg=MUTED, font=("Consolas", 8))
        self.task_date_label.pack(side="right")

        add_row = tk.Frame(self.tasks_panel, bg=PANEL)
        add_row.pack(fill="x", pady=(0, 8))
        self.task_entry_var = tk.StringVar()
        self.task_entry = tk.Entry(add_row, textvariable=self.task_entry_var,
                                   bg=PANEL_2, fg=TEXT, insertbackground=TEXT,
                                   relief="flat", bd=0, highlightthickness=1,
                                   highlightbackground="#30343D", highlightcolor=SKY,
                                   font=("Segoe UI", 10))
        self.task_entry.pack(side="left", fill="x", expand=True, ipady=7, padx=(0, 6))
        self.task_entry.bind("<Return>", self._add_task_event)
        self._make_button(add_row, "+ AÑADIR", self.add_task, MINT,
                          strong=True, width=9).pack(side="right")

        # The scrollable checklist is the expandable section, so it fills the gap
        # instead of leaving unused space above the Spotify mini-player.
        list_frame = tk.Frame(self.tasks_panel, bg=PANEL)
        list_frame.pack(fill="both", expand=True)
        self.tasks_canvas = tk.Canvas(list_frame, height=110, bg=PANEL,
                                      highlightthickness=1,
                                      highlightbackground="#30343D", bd=0)
        self.tasks_scrollbar = tk.Scrollbar(list_frame, orient="vertical",
                                            command=self.tasks_canvas.yview,
                                            bg=PANEL_2, troughcolor=PANEL,
                                            activebackground=SKY, relief="flat", bd=0,
                                            highlightthickness=0, width=10)
        self.tasks_canvas.configure(yscrollcommand=self.tasks_scrollbar.set)
        self.tasks_canvas.pack(side="left", fill="both", expand=True)
        self.tasks_scrollbar.pack(side="right", fill="y")
        self.tasks_inner = tk.Frame(self.tasks_canvas, bg=PANEL)
        self.tasks_window = self.tasks_canvas.create_window(
            (0, 0), window=self.tasks_inner, anchor="nw")
        self.tasks_inner.bind("<Configure>", self._update_tasks_scrollregion)
        self.tasks_canvas.bind("<Configure>", self._resize_tasks_inner)
        self.tasks_canvas.bind("<MouseWheel>", self._scroll_tasks)
        self.tasks_inner.bind("<MouseWheel>", self._scroll_tasks)

        footer = tk.Frame(self.tasks_panel, bg=PANEL)
        footer.pack(fill="x", pady=(6, 0))
        self.tasks_counter = tk.Label(footer, text="0/0 COMPLETADAS", bg=PANEL,
                                      fg=MUTED, font=("Consolas", 8))
        self.tasks_counter.pack(side="left")
        self._make_button(footer, "LIMPIAR HECHAS", self.clear_completed_tasks,
                          PINK, width=13).pack(side="right")
        self.tasks_error = tk.Label(self.tasks_panel, text="", bg=PANEL, fg=RED,
                                    font=("Segoe UI", 8), justify="left",
                                    wraplength=290, anchor="w")
        self.tasks_error.pack(fill="x", pady=(3, 0))
        self._render_tasks()

    @staticmethod
    def _tasks_storage_path() -> Path:
        """Choose a per-user data folder, rather than writing beside the EXE."""
        if os.name == "nt":
            base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
        else:
            base = Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))
        return base / "Nightstand" / "daily_tasks.json"

    @staticmethod
    def _format_task_date() -> str:
        return date.today().strftime("%d/%m/%Y")

    def _load_daily_tasks(self, day_key: str) -> list[dict[str, object]]:
        try:
            with self.tasks_file.open("r", encoding="utf-8") as file:
                store = json.load(file)
            if not isinstance(store, dict):
                return []
            raw_tasks = store.get(day_key, [])
            if not isinstance(raw_tasks, list):
                return []
            tasks = []
            for entry in raw_tasks:
                if not isinstance(entry, dict):
                    continue
                text = entry.get("text")
                if isinstance(text, str) and text.strip():
                    tasks.append({"text": text.strip()[:300], "done": bool(entry.get("done", False))})
            return tasks
        except (OSError, json.JSONDecodeError, TypeError):
            return []

    def _save_daily_tasks(self) -> None:
        try:
            self.tasks_file.parent.mkdir(parents=True, exist_ok=True)
            store: dict[str, list[dict[str, object]]] = {}
            try:
                with self.tasks_file.open("r", encoding="utf-8") as file:
                    loaded = json.load(file)
                if isinstance(loaded, dict):
                    store = loaded
            except (OSError, json.JSONDecodeError):
                pass
            store[self.task_date] = [
                {"text": str(task["text"]), "done": bool(task.get("done", False))}
                for task in self.daily_tasks
            ]
            with self.tasks_file.open("w", encoding="utf-8") as file:
                json.dump(store, file, ensure_ascii=False, indent=2)
            if hasattr(self, "tasks_error"):
                self.tasks_error.configure(text="")
        except OSError as exc:
            if hasattr(self, "tasks_error"):
                self.tasks_error.configure(text=f"No se pudo guardar la lista: {exc}")

    def _render_tasks(self) -> None:
        if not hasattr(self, "tasks_inner"):
            return
        for widget in self.tasks_inner.winfo_children():
            widget.destroy()
        if not self.daily_tasks:
            tk.Label(self.tasks_inner, text="Aún no hay tareas. Añade la primera arriba.",
                     bg=PANEL, fg="#777F8D", font=("Segoe UI", 9),
                     wraplength=240, justify="left", anchor="w").pack(
                         fill="x", padx=7, pady=10)
        else:
            for index, task in enumerate(self.daily_tasks):
                row = tk.Frame(self.tasks_inner, bg=PANEL)
                row.pack(fill="x", padx=4, pady=2)
                done = bool(task.get("done", False))
                variable = tk.BooleanVar(value=done)
                check = tk.Checkbutton(
                    row, text=str(task.get("text", "")), variable=variable,
                    command=lambda i=index, v=variable: self._toggle_task(i, v),
                    anchor="w", justify="left", wraplength=215,
                    bg=PANEL, fg=(MUTED if done else TEXT),
                    activebackground=PANEL, activeforeground=TEXT,
                    selectcolor=MINT_DARK, disabledforeground=MUTED,
                    font=("Segoe UI", 9, "overstrike" if done else "normal"),
                    relief="flat", bd=0, highlightthickness=0, padx=3, pady=2,
                    cursor="hand2")
                check.pack(side="left", fill="x", expand=True)
                delete_button = tk.Button(
                    row, text="×", command=lambda i=index: self.delete_task(i),
                    bg=PANEL, fg=PINK, activebackground=PANEL_2,
                    activeforeground=TEXT, relief="flat", bd=0,
                    font=("Segoe UI", 11, "bold"), padx=7, pady=0,
                    cursor="hand2")
                delete_button.pack(side="right", padx=(2, 0))
        self.tasks_canvas.configure(scrollregion=self.tasks_canvas.bbox("all"))
        self._update_tasks_counter()

    def _update_tasks_scrollregion(self, _event=None) -> None:
        if hasattr(self, "tasks_canvas"):
            self.tasks_canvas.configure(scrollregion=self.tasks_canvas.bbox("all"))

    def _resize_tasks_inner(self, event) -> None:
        if hasattr(self, "tasks_window"):
            self.tasks_canvas.itemconfigure(self.tasks_window, width=event.width)

    def _scroll_tasks(self, event):
        self.tasks_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        return "break"

    def _update_tasks_counter(self) -> None:
        total = len(self.daily_tasks)
        completed = sum(bool(task.get("done", False)) for task in self.daily_tasks)
        self.tasks_counter.configure(text=f"{completed}/{total} COMPLETADAS")

    def _add_task_event(self, _event=None):
        self.add_task()
        return "break"

    def add_task(self) -> None:
        text = self.task_entry_var.get().strip()
        if not text:
            self.task_entry.focus_set()
            return
        self.daily_tasks.append({"text": text[:300], "done": False})
        self.task_entry_var.set("")
        self.tasks_error.configure(text="")
        self._save_daily_tasks()
        self._render_tasks()
        self.tasks_canvas.yview_moveto(1.0)
        self.task_entry.focus_set()

    def _toggle_task(self, index: int, variable: tk.BooleanVar) -> None:
        if 0 <= index < len(self.daily_tasks):
            self.daily_tasks[index]["done"] = bool(variable.get())
            self._save_daily_tasks()
            self._update_tasks_counter()
            # Update only the clicked row, preserving the current scroll position.
            rows = self.tasks_inner.winfo_children()
            if index < len(rows):
                for child in rows[index].winfo_children():
                    if isinstance(child, tk.Checkbutton):
                        done = bool(variable.get())
                        child.configure(fg=(MUTED if done else TEXT),
                                        font=("Segoe UI", 9, "overstrike" if done else "normal"))
                        break

    def delete_task(self, index: int) -> None:
        if 0 <= index < len(self.daily_tasks):
            del self.daily_tasks[index]
            self._save_daily_tasks()
            self._render_tasks()

    def clear_completed_tasks(self) -> None:
        self.daily_tasks = [task for task in self.daily_tasks if not task.get("done", False)]
        self._save_daily_tasks()
        self._render_tasks()

    def _schedule_task_day_check(self) -> None:
        if not self.closing:
            self._daily_task_job = self.root.after(60_000, self._check_task_day)

    def _check_task_day(self) -> None:
        if self.closing:
            return
        today = date.today().isoformat()
        if today != self.task_date:
            self._save_daily_tasks()
            self.task_date = today
            self.daily_tasks = self._load_daily_tasks(today)
            self.task_date_label.configure(text=self._format_task_date())
            self._render_tasks()
        self._schedule_task_day_check()

    def _build_workspace(self):
        top = tk.Frame(self.workspace, bg=BG)
        top.grid(row=0, column=0, sticky="ew")
        top.grid_columnconfigure(0, weight=1)
        title_box = tk.Frame(top, bg=BG)
        title_box.grid(row=0, column=0, sticky="w")
        tk.Label(title_box, text="FOCUS TIMER", bg=BG, fg=TEXT,
                 font=("Segoe UI", 12, "bold")).pack(anchor="w")
        tk.Label(title_box, text="A QUIET SPACE FOR YOUR TIME", bg=BG, fg=MUTED,
                 font=("Consolas", 9)).pack(anchor="w", pady=(4, 0))
        actions = tk.Frame(top, bg=BG)
        actions.grid(row=0, column=1, sticky="e")
        self.panel_toggle_button = self._make_button(actions, "PANEL ◂", self.toggle_sidebar, SKY)
        self.panel_toggle_button.pack(side="left", padx=4)
        self._make_button(actions, "⛶", self.toggle_fullscreen, CREAM, width=4).pack(side="left", padx=4)
        self._make_button(actions, "×", self.close_app, PINK, width=4).pack(side="left", padx=(4, 0))

        center = tk.Frame(self.workspace, bg=BG)
        center.grid(row=1, column=0, sticky="nsew")
        center.grid_columnconfigure(0, weight=1)
        center.grid_rowconfigure(0, weight=1)
        center.grid_rowconfigure(4, weight=1)

        self.timer_canvas = tk.Canvas(center, bg=BG, highlightthickness=0, bd=0, height=190)
        self.timer_canvas.grid(row=1, column=0, sticky="ew", pady=(12, 0))
        self.timer_canvas.bind("<Configure>", lambda _e: self._draw_timer())

        self.timer_state_label = tk.Label(center, text="READY WHEN YOU ARE", bg=BG,
                                           fg=MUTED, font=("Consolas", 10, "bold"))
        self.timer_state_label.grid(row=2, column=0, pady=(0, 28))

        editor = tk.Frame(center, bg=BG)
        editor.grid(row=3, column=0, pady=(0, 20))
        tk.Label(editor, text="SET DURATION", bg=BG, fg=MUTED,
                 font=("Consolas", 9, "bold")).grid(row=0, column=0, columnspan=5, pady=(0, 12))

        self.hour_var = tk.StringVar(value="00")
        self.minute_var = tk.StringVar(value="25")
        self.second_var = tk.StringVar(value="00")
        fields = [(self.hour_var, "HOURS", 99), (self.minute_var, "MINUTES", 59),
                  (self.second_var, "SECONDS", 59)]
        for col, (var, label, maximum) in enumerate(fields):
            if col:
                tk.Label(editor, text=":", bg=BG, fg="#626975",
                         font=("Consolas", 25)).grid(row=1, column=col * 2 - 1, padx=7)
            box = tk.Spinbox(editor, from_=0, to=maximum, wrap=True, width=3,
                             textvariable=var, format="%02.0f", justify="center",
                             font=("Consolas", 19), bg=PANEL, fg=TEXT,
                             buttonbackground=PANEL_2, insertbackground=TEXT,
                             relief="flat", bd=0, highlightthickness=1,
                             highlightbackground="#30343D", highlightcolor=SKY)
            box.grid(row=1, column=col * 2, ipady=8, ipadx=4)
            tk.Label(editor, text=label, bg=BG, fg="#727A88",
                     font=("Consolas", 8)).grid(row=2, column=col * 2, pady=(7, 0))
            var.trace_add("write", self._time_field_changed)

        controls = tk.Frame(center, bg=BG)
        controls.grid(row=4, column=0, pady=(0, 5), sticky="n")
        self._make_button(controls, "▶  INICIAR", self.start_timer, MINT,
                          strong=True, width=14).pack(side="left", padx=6, ipady=4)
        self._make_button(controls, "Ⅱ  PAUSAR", self.pause_timer, SKY,
                          width=13).pack(side="left", padx=6, ipady=4)
        self._make_button(controls, "↺  REINICIAR", self.reset_timer, PINK,
                          width=14).pack(side="left", padx=6, ipady=4)

        self.timer_hint = tk.Label(center, text="ESC sale de pantalla completa · F11 alterna pantalla completa",
                                   bg=BG, fg="#626975", font=("Segoe UI", 9))
        self.timer_hint.grid(row=5, column=0, pady=(25, 0))
        tk.Label(center, text="DESIGNED FOR STILLNESS  •  01", bg=BG, fg="#363B45",
                 font=("Consolas", 8)).grid(row=6, column=0, pady=(22, 0))

    @staticmethod
    def _make_button(parent, text, command, accent, width=None, strong=False):
        options = dict(text=text, command=command, bg=accent, fg="#111318",
                       activebackground=TEXT, activeforeground="#111318",
                       relief="flat", bd=0, padx=12, pady=9,
                       font=("Segoe UI", 9, "bold" if strong else "normal"),
                       cursor="hand2", takefocus=True)
        if width is not None:
            options["width"] = width
        return tk.Button(parent, **options)

    def _draw_timer(self):
        if not hasattr(self, "timer_canvas"):
            return
        c = self.timer_canvas
        c.delete("all")
        width = max(c.winfo_width(), 300)
        height = max(c.winfo_height(), 160)
        font_size = int(max(42, min(112, width / 10.4, height / 1.7)))
        time_text = self._format_seconds(self.remaining_seconds)
        x, y = width / 2, height / 2
        # A few low-opacity-looking offset layers create a soft digital glow.
        c.create_text(x + 2, y + 2, text=time_text, fill="#112A20",
                      font=("Consolas", font_size, "bold"), anchor="center")
        c.create_text(x + 1, y + 1, text=time_text, fill="#1E4B37",
                      font=("Consolas", font_size, "bold"), anchor="center")
        c.create_text(x, y, text=time_text, fill=MINT,
                      font=("Consolas", font_size, "bold"), anchor="center")

    @staticmethod
    def _format_seconds(seconds: int) -> str:
        seconds = max(0, int(seconds))
        hours, remain = divmod(seconds, 3600)
        minutes, secs = divmod(remain, 60)
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"

    def _read_fields_seconds(self) -> int:
        def safe_int(value: str, maximum: int) -> int:
            try:
                return max(0, min(maximum, int(value.strip() or "0")))
            except (ValueError, AttributeError):
                return 0
        hours = safe_int(self.hour_var.get(), 99)
        minutes = safe_int(self.minute_var.get(), 59)
        seconds = safe_int(self.second_var.get(), 59)
        return hours * 3600 + minutes * 60 + seconds

    def _sync_time_fields(self):
        total = max(0, int(self.remaining_seconds))
        hours, rem = divmod(total, 3600)
        minutes, seconds = divmod(rem, 60)
        for var, value in ((self.hour_var, f"{hours:02d}"),
                           (self.minute_var, f"{minutes:02d}"),
                           (self.second_var, f"{seconds:02d}")):
            if var.get() != value:
                var.set(value)

    def _time_field_changed(self, *_args):
        if self.timer_state in ("idle", "finished"):
            self.remaining_seconds = self._read_fields_seconds()
            self._draw_timer()

    def _tick_timer(self):
        if self.closing:
            return
        if self.timer_state == "running" and self.deadline is not None:
            self.remaining_seconds = max(0, math.ceil(self.deadline - time.monotonic()))
            if self.remaining_seconds <= 0:
                self.remaining_seconds = 0
                self.deadline = None
                self.timer_state = "finished"
                self.timer_state_label.configure(text="TIME IS UP", fg=PINK)
                try:
                    self.root.bell()
                except tk.TclError:
                    pass
            self._draw_timer()
        self._timer_job = self.root.after(100, self._tick_timer)

    def start_timer(self):
        if self.timer_state in ("idle", "finished"):
            self.remaining_seconds = self._read_fields_seconds()
        if self.remaining_seconds <= 0:
            messagebox.showinfo("Temporizador", "Selecciona una duración mayor que cero.", parent=self.root)
            return
        self.deadline = time.monotonic() + self.remaining_seconds
        self.timer_state = "running"
        self.timer_state_label.configure(text="COUNTDOWN IN PROGRESS", fg=MINT)
        self._draw_timer()

    def pause_timer(self):
        if self.timer_state == "running" and self.deadline is not None:
            self.remaining_seconds = max(0, math.ceil(self.deadline - time.monotonic()))
            self.deadline = None
            self.timer_state = "paused"
            self.timer_state_label.configure(text="PAUSED", fg=SKY)
            self._draw_timer()
        elif self.timer_state == "paused":
            self.timer_state_label.configure(text="PAUSED · PRESS START TO RESUME", fg=SKY)

    def reset_timer(self):
        self.deadline = None
        self.timer_state = "idle"
        self.remaining_seconds = self._read_fields_seconds()
        self.timer_state_label.configure(text="READY WHEN YOU ARE", fg=MUTED)
        self._draw_timer()

    def toggle_sidebar(self):
        if self.sidebar_visible:
            self.sidebar.grid_remove()
            self.sidebar_visible = False
            self.panel_toggle_button.configure(text="PANEL ▸")
        else:
            self.sidebar.grid(row=0, column=0, sticky="nsw")
            self.sidebar_visible = True
            self.panel_toggle_button.configure(text="PANEL ◂")

    def toggle_fullscreen(self, _event=None):
        self.is_fullscreen = not self.is_fullscreen
        try:
            self.root.attributes("-fullscreen", self.is_fullscreen)
            if not self.is_fullscreen:
                self.root.state("normal")
                self.root.geometry("1200x800")
        except tk.TclError:
            pass
        return "break"

    def _escape_action(self, _event=None):
        if self.is_fullscreen:
            self.is_fullscreen = False
            try:
                self.root.attributes("-fullscreen", False)
                self.root.state("normal")
                self.root.geometry("1200x800")
            except tk.TclError:
                pass
        else:
            self.close_app()
        return "break"

    def _load_saved_credentials(self):
        if not _keyring_usable() or keyring is None:
            return
        try:
            self.spotify_client_id = keyring.get_password(KEYRING_SERVICE, "client_id") or ""
            self.spotify_client_secret = keyring.get_password(KEYRING_SERVICE, "client_secret") or ""
        except Exception:
            self.spotify_client_id = ""
            self.spotify_client_secret = ""

    def open_spotify_settings(self):
        if not SPOTIPY_AVAILABLE:
            messagebox.showerror("Falta Spotipy", "Instala las dependencias con:\n\npython -m pip install -r requirements.txt",
                                 parent=self.root)
            return
        dialog = tk.Toplevel(self.root)
        dialog.title("Ajustes de Spotify")
        dialog.configure(bg=PANEL)
        dialog.transient(self.root)
        dialog.resizable(False, False)
        dialog.grab_set()
        dialog.geometry("520x360")
        dialog.update_idletasks()
        x = self.root.winfo_rootx() + max(0, (self.root.winfo_width() - 520) // 2)
        y = self.root.winfo_rooty() + max(0, (self.root.winfo_height() - 360) // 2)
        dialog.geometry(f"520x360+{x}+{y}")

        tk.Label(dialog, text="CONECTAR CON SPOTIFY", bg=PANEL, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=24, pady=(22, 3))
        tk.Label(dialog, text="Las credenciales se guardan en el almacén seguro del sistema cuando está disponible.",
                 bg=PANEL, fg=MUTED, font=("Segoe UI", 9), wraplength=460,
                 justify="left").pack(anchor="w", padx=24, pady=(0, 14))

        client_id_var = tk.StringVar(value=self.spotify_client_id)
        client_secret_var = tk.StringVar(value=self.spotify_client_secret)
        redirect_var = tk.StringVar(value=self.redirect_uri)
        form = tk.Frame(dialog, bg=PANEL)
        form.pack(fill="x", padx=24)

        def add_entry(label, var, show=None):
            tk.Label(form, text=label, bg=PANEL, fg=SKY,
                     font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(5, 4))
            entry = tk.Entry(form, textvariable=var, show=show, bg="#090A0D", fg=TEXT,
                             insertbackground=TEXT, relief="flat", bd=0,
                             highlightthickness=1, highlightbackground="#373B46",
                             highlightcolor=SKY, font=("Consolas", 10))
            entry.pack(fill="x", ipady=7)
            return entry

        add_entry("CLIENT ID", client_id_var)
        add_entry("CLIENT SECRET", client_secret_var, show="•")
        add_entry("REDIRECT URI (debe coincidir exactamente con el Dashboard)", redirect_var)
        bottom = tk.Frame(dialog, bg=PANEL)
        bottom.pack(fill="x", padx=24, pady=18)

        def forget_credentials():
            if not messagebox.askyesno("Borrar credenciales", "¿Borrar las credenciales y el token guardado?",
                                       parent=dialog):
                return
            try:
                if _keyring_usable() and keyring is not None:
                    for username in ("client_id", "client_secret",
                                     f"oauth_token::{self.spotify_client_id}"):
                        try:
                            keyring.delete_password(KEYRING_SERVICE, username)
                        except Exception:
                            pass
            finally:
                _TOKEN_MEMORY_CACHE.clear()
                self.spotify_client_id = ""
                self.spotify_client_secret = ""
                self.sp_client = None
                self.spotify_status.configure(text="Credenciales borradas · Spotify desconectado", fg=MUTED)
                self.track_title.configure(text="Sin conexión")
                self.track_artist.configure(text="Conecta tu cuenta de Spotify")
                self.track_album.configure(text="")
                dialog.destroy()

        self._make_button(bottom, "OLVIDAR", forget_credentials, PINK).pack(side="left")

        def save_and_connect():
            client_id = client_id_var.get().strip()
            client_secret = client_secret_var.get().strip()
            redirect_uri = redirect_var.get().strip()
            parsed = urlparse(redirect_uri)
            if not client_id or not client_secret:
                messagebox.showwarning("Faltan datos", "Introduce el Client ID y el Client Secret.", parent=dialog)
                return
            if (parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or not parsed.port
                    or not parsed.path):
                messagebox.showwarning("Redirect URI no válido",
                                       "Usa el URI local con IP, puerto y ruta, por ejemplo:\n" + REDIRECT_URI,
                                       parent=dialog)
                return
            self.spotify_client_id = client_id
            self.spotify_client_secret = client_secret
            self.redirect_uri = redirect_uri
            stored = False
            if _keyring_usable() and keyring is not None:
                try:
                    keyring.set_password(KEYRING_SERVICE, "client_id", client_id)
                    keyring.set_password(KEYRING_SERVICE, "client_secret", client_secret)
                    stored = True
                except Exception:
                    stored = False
            dialog.destroy()
            if stored:
                self.spotify_status.configure(text="Credenciales guardadas en el almacén seguro · conectando…", fg=SKY)
            else:
                self.spotify_status.configure(text="Almacén seguro no disponible: credenciales solo en memoria · conectando…",
                                              fg=CREAM)
            self.connect_spotify()

        self._make_button(bottom, "GUARDAR Y CONECTAR", save_and_connect, MINT,
                          strong=True).pack(side="right")
        dialog.bind("<Escape>", lambda _e: dialog.destroy())

    def connect_spotify(self):
        if not SPOTIPY_AVAILABLE:
            return
        if not self.spotify_client_id or not self.spotify_client_secret:
            self.open_spotify_settings()
            return
        client_id = self.spotify_client_id
        client_secret = self.spotify_client_secret
        redirect_uri = self.redirect_uri
        self.spotify_status.configure(text="Abriendo autorización de Spotify…", fg=SKY)

        def task():
            cache = SecureTokenCache(client_id)
            oauth = SpotifyOAuth(client_id=client_id,
                                 client_secret=client_secret,
                                 redirect_uri=redirect_uri,
                                 scope=SPOTIFY_SCOPES,
                                 state=secrets.token_urlsafe(24),
                                 cache_handler=cache,
                                 open_browser=False,
                                 requests_timeout=15)
            token = oauth.validate_token(cache.get_cached_token())
            if token is None:
                auth_url = oauth.get_authorize_url()
                code = _receive_oauth_code(redirect_uri, oauth.state or "", auth_url,
                                           cancel_event=self.cancel_event)
                oauth.get_access_token(code=code, check_cache=False)
            client = spotipy.Spotify(auth_manager=oauth, requests_timeout=15)
            playback = client.current_playback()
            image_bytes = self._download_album_art(playback)
            return client, playback, image_bytes, cache._keyring_enabled

        self._submit_spotify(task, self._connected, show_error=True,
                             busy_text="Esperando autorización de Spotify…")

    @staticmethod
    def _download_album_art(playback):
        try:
            images = playback["item"]["album"].get("images", [])
            if not images:
                return None
            with urlopen(images[0]["url"], timeout=5) as response:
                return response.read(4 * 1024 * 1024)
        except (KeyError, TypeError, URLError, TimeoutError, OSError):
            return None

    def _submit_spotify(self, work, on_success=None, show_error=False, busy_text=None):
        if self.spotify_pending:
            return
        if not SPOTIPY_AVAILABLE:
            messagebox.showerror("Falta Spotipy", "Instala las dependencias con requirements.txt", parent=self.root)
            return
        self.spotify_pending = True
        if busy_text:
            self.spotify_status.configure(text=busy_text, fg=SKY)

        future = self.executor.submit(work)

        def completed(future_obj):
            try:
                result = future_obj.result()
                error = None
            except Exception as exc:  # Spotipy/HTTP/network errors are surfaced to the user.
                result, error = None, exc

            def on_ui_thread():
                self.spotify_pending = False
                if self.closing:
                    return
                if error is not None:
                    text = f"Spotify: {error}"
                    self.spotify_status.configure(text=text[:320], fg=RED)
                    if show_error:
                        messagebox.showerror("No se pudo completar la acción de Spotify",
                                             f"{text}\n\nComprueba las credenciales, el Redirect URI, los permisos, "
                                             "la lista de usuarios autorizados y tu dispositivo Spotify activo.",
                                             parent=self.root)
                elif on_success is not None:
                    on_success(result)

            try:
                self.root.after(0, on_ui_thread)
            except tk.TclError:
                pass

        future.add_done_callback(completed)

    def _connected(self, result):
        self.sp_client, playback, image_bytes, secure_cache = result
        if secure_cache:
            self.spotify_status.configure(text="Spotify conectado · token en almacén seguro", fg=MINT)
        else:
            self.spotify_status.configure(text="Spotify autorizado · token solo en memoria en esta sesión", fg=CREAM)
        self._render_playback((playback, image_bytes))

    @staticmethod
    def _track_key(playback):
        """Return a stable identifier for the current track, if any."""
        item = (playback or {}).get("item") or {}
        return item.get("id") or item.get("uri") or item.get("name")

    def _fetch_playback(self):
        """Fetch playback state; only download album art when the track changes."""
        if self.sp_client is None:
            raise RuntimeError("Conecta Spotify primero.")
        playback = self.sp_client.current_playback()
        image_bytes = None
        track_key = self._track_key(playback)
        if track_key and track_key != self._current_track_id:
            image_bytes = self._download_album_art(playback)
        return playback, image_bytes

    @staticmethod
    def _format_track_time(milliseconds: int | float | None) -> str:
        total_seconds = max(0, int((milliseconds or 0) / 1000))
        minutes, seconds = divmod(total_seconds, 60)
        return f"{minutes}:{seconds:02d}"

    def _render_playback(self, result):
        playback, image_bytes = result
        if not playback or not playback.get("item"):
            self._current_track_id = None
            self._playback_progress_ms = 0
            self._playback_duration_ms = 0
            self._playback_is_playing = False
            self._playback_sync_monotonic = time.monotonic()
            self.track_title.configure(text="Nada en reproducción")
            self.track_artist.configure(text="Abre Spotify y selecciona un dispositivo.")
            self.track_album.configure(text="")
            self._set_album_art(None)
            self.track_progress.configure(value=0)
            self.track_elapsed.configure(text="0:00")
            self.track_duration.configure(text="0:00")
            self.play_toggle_button.configure(text="▶", command=self.spotify_play)
            self.spotify_status.configure(
                text="Conectado · inicia Spotify en un dispositivo activo", fg=SKY)
            return

        item = playback.get("item") or {}
        track_key = self._track_key(playback)
        track_changed = track_key != self._current_track_id
        self._current_track_id = track_key
        artists = ", ".join(
            artist.get("name", "") for artist in item.get("artists", [])
            if artist.get("name"))
        album = (item.get("album") or {}).get("name", "")
        self.track_title.configure(text=item.get("name", "Tema desconocido"))
        self.track_artist.configure(text=artists or "Artista desconocido")
        self.track_album.configure(text=album)
        # Keep the current cover while polling the same track; avoid reloading it.
        if track_changed or image_bytes is not None:
            self._set_album_art(image_bytes)

        self._playback_progress_ms = int(playback.get("progress_ms") or 0)
        self._playback_duration_ms = int(item.get("duration_ms") or 0)
        self._playback_is_playing = bool(playback.get("is_playing"))
        self._playback_sync_monotonic = time.monotonic()
        self._update_track_progress_display()
        is_playing = self._playback_is_playing
        self.play_toggle_button.configure(
            text="Ⅱ" if is_playing else "▶",
            command=self.spotify_pause if is_playing else self.spotify_play)

        device = playback.get("device") or {}
        state = "reproduciendo" if is_playing else "en pausa"
        device_name = device.get("name") or "dispositivo Spotify"
        self.spotify_status.configure(
            text=f"Spotify conectado · {state} en {device_name}", fg=MINT)
        volume = device.get("volume_percent")
        if volume is not None:
            self.volume_scale.set(int(volume))
            self.volume_value.configure(text=f"{int(volume)}%")

    def _set_album_art(self, image_bytes):
        if not image_bytes or not PIL_AVAILABLE:
            self.album_photo = None
            self.art_placeholder.configure(image="", text="♫", bg="#25352A", fg=SPOTIFY_GREEN,
                                           font=("Segoe UI Symbol", 16, "bold"))
            return
        try:
            image_obj = Image.open(io.BytesIO(image_bytes)).convert("RGB")
            image_obj.thumbnail((58, 58))
            self.album_photo = ImageTk.PhotoImage(image_obj)
            self.art_placeholder.configure(image=self.album_photo, text="", width=58, height=58,
                                           bg="#25352A", relief="flat")
        except Exception:
            self.album_photo = None
            self.art_placeholder.configure(image="", text="♫", bg="#25352A", fg=SPOTIFY_GREEN,
                                           font=("Segoe UI Symbol", 16, "bold"))

    def _spotify_control(self, action_name: str, operation):
        if self.sp_client is None:
            self.open_spotify_settings()
            return

        def task():
            operation(self.sp_client)
            time.sleep(0.15)  # give Spotify Connect a moment to update its reported state
            return self._fetch_playback()

        self._submit_spotify(task, self._render_playback, show_error=True,
                             busy_text=f"Spotify · {action_name}…")

    def spotify_play(self):
        self._spotify_control("reanudar", lambda sp: sp.start_playback())

    def spotify_pause(self):
        self._spotify_control("pausar", lambda sp: sp.pause_playback())

    def spotify_next(self):
        self._spotify_control("siguiente", lambda sp: sp.next_track())

    def spotify_previous(self):
        self._spotify_control("anterior", lambda sp: sp.previous_track())

    def _volume_preview(self, value):
        self.volume_value.configure(text=f"{int(float(value))}%")

    def _apply_volume(self, _event=None):
        if self.sp_client is None:
            self.spotify_status.configure(text="Conecta Spotify antes de cambiar el volumen.", fg=CREAM)
            return
        volume = int(self.volume_scale.get())
        self._spotify_control(f"volumen {volume}%", lambda sp: sp.volume(volume))

    def _update_track_progress_display(self):
        """Update the elapsed clock and progress bar from the last Spotify sync."""
        elapsed_ms = self._playback_progress_ms
        if self._playback_is_playing:
            elapsed_ms += int((time.monotonic() - self._playback_sync_monotonic) * 1000)
        if self._playback_duration_ms > 0:
            elapsed_ms = min(elapsed_ms, self._playback_duration_ms)
            ratio = min(100.0, elapsed_ms * 100.0 / self._playback_duration_ms)
        else:
            elapsed_ms = max(0, elapsed_ms)
            ratio = 0.0
        self.track_progress.configure(value=ratio)
        self.track_elapsed.configure(text=self._format_track_time(elapsed_ms))
        if self._playback_duration_ms > 0:
            self.track_duration.configure(
                text=self._format_track_time(self._playback_duration_ms))

    def _schedule_track_progress_tick(self):
        """Refresh the visible playback clock every second without extra API calls."""
        if not self.closing:
            self.track_progress_job = self.root.after(1000, self._track_progress_tick)

    def _track_progress_tick(self):
        if self.closing:
            return
        self._update_track_progress_display()
        self._schedule_track_progress_tick()

    def _schedule_spotify_poll(self):
        if self.closing:
            return
        # Sync remote play/pause/track changes periodically. The visible progress
        # indicator itself advances every second locally to keep API use modest.
        self.spotify_poll_job = self.root.after(4000, self._spotify_poll)

    def _spotify_poll(self):
        if self.closing:
            return
        if self.sp_client is not None and not self.spotify_pending:
            self._submit_spotify(self._fetch_playback, self._render_playback,
                                 show_error=False)
        self._schedule_spotify_poll()

    def close_app(self):
        if self.closing:
            return
        self.closing = True
        self.cancel_event.set()
        self._save_daily_tasks()
        for job in (self.spotify_poll_job, self.track_progress_job,
                    self._timer_job, self._daily_task_job):
            if job is not None:
                try:
                    self.root.after_cancel(job)
                except tk.TclError:
                    pass
        try:
            self.executor.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass
        try:
            self.root.destroy()
        except tk.TclError:
            pass


def main():
    root = tk.Tk()
    app = NightstandApp(root)
    if not PIL_AVAILABLE:
        app.spotify_status.configure(text="Pillow no está instalado: la portada no estará disponible.", fg=CREAM)
    root.mainloop()


if __name__ == "__main__":
    main()
