# NIGHTSTAND — temporizador, checklist diaria y Spotify

Aplicación de escritorio para Windows con Python/Tkinter. Incluye cuenta atrás configurable, pantalla oscura, lista diaria de tareas con casillas de verificación y una barra compacta inspirada en Spotify, anclada a la esquina inferior del panel izquierdo, con portada, canción/artista, progreso, reproducción y volumen.

## 1. Requisitos

- Windows 10/11.
- Python 3.10 o superior instalado desde [python.org](https://www.python.org/downloads/windows/), con **Tcl/Tk** incluido. En el instalador, activa **Add Python to PATH**.
- Cuenta Spotify. Para apps nuevas en Development Mode, el propietario de la app necesita Spotify Premium y la app admite hasta cinco usuarios autorizados. Además, los endpoints de control de reproducción requieren Premium y un dispositivo Spotify activo.

## 2. Instalar dependencias

Abre PowerShell en la carpeta `nightstand_app` (donde están `nightstand_spotify.py` y `requirements.txt`) y ejecuta:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt
```

No es obligatorio activar el entorno virtual. Si el comando `python` no se reconoce, instala Python desde [python.org](https://www.python.org/downloads/windows/) y marca **Add Python to PATH**; también puedes probar `python3 --version` para localizar una instalación existente.

## 3. Crear credenciales de Spotify

1. Abre el [Spotify Developer Dashboard](https://developer.spotify.com/dashboard) e inicia sesión.
2. Crea una app desde **Create app** y acepta los términos aplicables.
3. Abre la configuración de la app (**Settings / Edit Settings**).
4. En **Redirect URIs**, añade exactamente:

   `http://127.0.0.1:8888/callback`

   Guarda los cambios. Usa la IP `127.0.0.1`, no `localhost`; el URI introducido en la aplicación debe coincidir exactamente con el registrado.
5. Copia **Client ID** y **Client Secret** de la página de la app. No publiques el Client Secret ni lo incluyas en repositorios.
6. Si la app está en **Development Mode**, comprueba que la cuenta propietaria tiene Premium y, en la pestaña **Users and Access**, añade las cuentas que vayan a autorizarla (máximo cinco usuarios autorizados según las reglas actuales de Spotify para ese modo).

## 4. Ejecutar

```powershell
python nightstand_spotify.py
```

La app se abre en pantalla completa. `Esc` sale del modo pantalla completa; al pulsar `Esc` otra vez se cierra la app. `F11` alterna pantalla completa. También hay controles visibles arriba a la derecha.

Configura horas/minutos/segundos y pulsa **Iniciar**. **Pausar** conserva el tiempo restante y **Reiniciar** vuelve a la duración definida en los campos.

En la parte superior del panel izquierdo, la sección **Lista de hoy** permite escribir tareas y añadirlas, marcarlas como completadas, borrarlas individualmente o limpiar todas las completadas. La lista se guarda automáticamente en `%LOCALAPPDATA%\Nightstand\daily_tasks.json` (Windows), separada por fecha; al cambiar el día se abre la lista correspondiente a esa fecha. La zona desplazable de la lista crece automáticamente para aprovechar el espacio disponible hasta la barra de música inferior.

En la barra de música de la esquina inferior izquierda, pulsa **Ajustes**, introduce Client ID y Client Secret y pulsa **Guardar y conectar**. El navegador se abrirá para que autorices los permisos de reproducción/lectura. La barra muestra la portada, el título, artista, progreso y duración de la canción; el contador y la barra de progreso visual se actualizan cada segundo entre sincronizaciones, mientras que el estado de Spotify se vuelve a consultar aproximadamente cada cuatro segundos para detectar pausas y cambios externos de pista. Sus controles permiten pasar a la pista anterior/siguiente, reproducir/pausar y modificar el volumen.

Spotify es quien reproduce el audio. Si aparece “inicia Spotify en un dispositivo activo”, abre la app de Spotify o el reproductor web, inicia la reproducción/selecciona un dispositivo Spotify Connect y vuelve a usar los controles.

### Seguridad de credenciales

La aplicación intenta usar `keyring` para guardar Client ID, Client Secret y token OAuth en el almacén seguro disponible del sistema (en Windows, normalmente el Administrador de credenciales). Si ese almacén no está disponible, las credenciales/token se conservan **solo en memoria durante esa ejecución**; la aplicación no los vuelca como texto plano en un archivo. El archivo `.exe` no contiene las credenciales del usuario.

## 5. Empaquetar un `.exe` con PyInstaller

Ejecuta desde PowerShell o CMD, en la misma carpeta y con el entorno virtual activado:

```powershell
python -m PyInstaller --noconfirm --clean --onefile --windowed --name NightstandSpotify --collect-all spotipy --collect-all keyring nightstand_spotify.py
```

El ejecutable generado estará en:

`dist\NightstandSpotify.exe`

No necesitas `--add-data` para esta versión, ya que la interfaz se genera desde el código. La portada se descarga en tiempo de ejecución. Compila en Windows para producir un ejecutable de Windows; PyInstaller no es un compilador cruzado fiable entre sistemas operativos.

Si tienes un icono `.ico`, puedes añadir `--icon app.ico` al comando. Para depurar un error durante las pruebas, elimina temporalmente `--windowed` y vuelve a compilar para que se vea la consola.

## Limitaciones conocidas

- Tkinter forma parte de las instalaciones habituales de Python para Windows; si tu distribución no incluye Tcl/Tk, reinstala Python con soporte Tcl/Tk.
- La API de Spotify cambia y aplica cuotas/modos de acceso. Un error `403` puede deberse a que la cuenta no está autorizada en Development Mode, a permisos o a restricciones de la app; `404`/`NO ACTIVE DEVICE` puede indicar que no hay un reproductor Spotify activo.
- La app controla un reproductor Spotify Connect, no implementa un decodificador o streaming propio.
