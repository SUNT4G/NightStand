@echo off
setlocal
cd /d "%~dp0"

echo ==================================================
echo NIGHTSTAND - Windows EXE builder
echo ==================================================
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python was not found.
  echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/
  echo During setup, enable "Add Python to PATH" and include Tcl/Tk.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  python -m venv .venv
  if errorlevel 1 goto :error
)

echo Installing/updating build dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :error
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo.
echo Building NightstandSpotify.exe...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name NightstandSpotify --collect-all spotipy --collect-all keyring --collect-all PIL nightstand_spotify.py
if errorlevel 1 goto :error

echo.
echo SUCCESS! Executable created at:
echo %CD%\dist\NightstandSpotify.exe
echo.
explorer "%CD%\dist"
pause
exit /b 0

:error
echo.
echo BUILD FAILED. Read the error messages above and check README_BUILD.txt.
pause
exit /b 1
