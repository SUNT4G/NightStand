NIGHTSTAND — BUILD THE WINDOWS EXE
==================================

Important: this package contains the source code and build scripts, not a prebuilt EXE.
A genuine Windows .exe must be built on Windows (locally or by the included GitHub Actions workflow).

OPTION A — Build directly on Windows
------------------------------------
1. Install Python 3.10 or newer from https://www.python.org/downloads/windows/.
   During setup, enable "Add Python to PATH" and include Tcl/Tk.
2. Extract all files into one folder.
3. Double-click build_windows.bat and allow it to finish.
4. The executable will be created at dist\NightstandSpotify.exe.
5. Upload that EXE to itch.io as the Windows download. Do not upload .venv, build\ or the .spec file.

OPTION B — Build with GitHub Actions
------------------------------------
1. Create a GitHub repository for this project.
2. Upload the contents of this package to the repository root, including the hidden
   .github/workflows/build-windows.yml file. Make sure .github is not omitted.
3. Push to branch main/master, or open the repository's Actions tab and run
   "Build NIGHTSTAND for Windows" using Run workflow.
4. Open the completed workflow run and download the artifact named
   NightstandSpotify-Windows-x64. It contains NightstandSpotify.exe.
5. Upload the EXE to itch.io.

NOTES
-----
- No Spotify Client ID, Client Secret, or personal token is embedded in the EXE.
  Each user configures their own Spotify credentials in the app.
- The application needs internet access for Spotify features, but the timer and daily
  task list can be used without connecting Spotify.
- This is an unsigned build. Windows SmartScreen may show a warning for new/unrecognized
  executables. Only distribute the EXE after testing it on a clean Windows PC.
- The GitHub Actions artifact is retained for 14 days by the included workflow.
